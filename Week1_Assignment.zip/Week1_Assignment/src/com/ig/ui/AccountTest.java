package com.ig.ui;

import com.ig.model.Account;
import com.ig.model.AccountType;
import com.ig.service.AccountService;
import com.ig.exception.*;

public class AccountTest {

    public static void main(String[] args) {
        AccountService service = new AccountService();
        try {
            Account acc1 = new Account(101, "user1", AccountType.SAVINGS, 1500f);
            Account acc2 = new Account(102, "user2", AccountType.CURRENT, 6000f);

            service.accountList.add(acc1);
            service.accountList.add(acc2);
            service.deposit(101, 500f);
            System.out.println("New balance for account 101: " + service.getBalance(101));
            service.withdraw(102, 1000f);
            System.out.println("New balance for account 102: " + service.getBalance(102));

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException | LowBalanceException e) {
            System.out.println(e.getMessage());
        }
    }
}
