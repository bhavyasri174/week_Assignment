package com.ig.service;

import com.ig.model.Account;
import com.ig.model.AccountType;
import com.ig.exception.AccountNotFoundException;
import com.ig.exception.InvalidAmountException;
import com.ig.exception.InsufficientFundsException;

import java.util.ArrayList;
import java.util.List;

public class AccountService {

    public List<Account> accountList = new ArrayList<>();
    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return true;
            }
        }
        throw new AccountNotFoundException("Account not found");
    }
    public void deposit(int accNumber, float amt) throws InvalidAmountException {
        if (amt < 0) {
            throw new InvalidAmountException("Amount cannot be negative");
        }
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                account.setBalance(account.getBalance() + amt);
                return;
            }
        }
    }

    // Method to withdraw money from an account
    public void withdraw(int accNumber, float amt) throws InvalidAmountException, InsufficientFundsException {
        if (amt < 500) {
            throw new InvalidAmountException("Minimum withdrawal is 500");
        }
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                if (account.getType() == AccountType.SAVINGS && account.getBalance() - amt < 1000) {
                    throw new InsufficientFundsException("Savings account must maintain a minimum balance of 1000");
                }
                if (account.getType() == AccountType.CURRENT && account.getBalance() - amt < 5000) {
                    throw new InsufficientFundsException("Current account must maintain a minimum balance of 5000");
                }
                account.setBalance(account.getBalance() - amt);
                return;
            }
        }
    }
    public float getBalance(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return account.getBalance();
            }
        }
        throw new AccountNotFoundException("Account not found");
    }
}
